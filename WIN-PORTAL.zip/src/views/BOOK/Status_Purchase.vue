<template>
  <div class="about">
    <h1>도서 구매 현황</h1>
  </div>
</template>
