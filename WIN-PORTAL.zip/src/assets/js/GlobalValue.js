/*eslint-disable no-unused-vars, no-empty*/

export default {

/*************************팝업 공통 변수 시작******************************* */
// 실패 알림 옵션
Err_option : { title: '알림', size: 'sm', buttonSize: 'sm', okVariant: 'danger', headerClass: 'p-2 border-bottom-0', footerClass: 'p-2 border-top-0', centered: true},

// 성공 알림 옵션
Success_option : { title: '알림', size: 'sm', buttonSize: 'sm', okVariant: 'primary', headerClass: 'p-2 border-bottom-0', footerClass: 'p-2 border-top-0', centered: true},

// Confirm 옵션
Info_option : {title: "알림", size: "sm", buttonSize: "sm", okVariant: "primary", cancelVariant: "danger", okTitle: "YES", cancelTitle: "NO", footerClass: "p-2",hideHeaderClose: false, centered: true}
/*************************팝업 공통 변수 끝******************************* */

}
